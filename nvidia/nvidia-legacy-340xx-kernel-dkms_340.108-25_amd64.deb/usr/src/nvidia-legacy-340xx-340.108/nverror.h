/* _NVRM_COPYRIGHT_BEGIN_
 *
 * Copyright 2011 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 *
 * _NVRM_COPYRIGHT_END_
 */

#ifndef _NV_ERROR_H_
#define _NV_ERROR_H_

const char *nvidia_error_strings[] = ERROR_STR_PUBLIC;

#endif /* _NV_ERROR_H_ */
